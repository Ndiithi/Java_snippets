package com.ecletics.usernmanager;

/**
 *
 * @author duncan
 */
public class User {
     public User(){}
}
